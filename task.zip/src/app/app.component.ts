import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  label = "button 1";
  label2 = "button 2"

  public text:any;

   functioncall(event:any) {
    this.text = event;
  }
}
