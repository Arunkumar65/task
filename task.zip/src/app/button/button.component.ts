import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-button',
  templateUrl: './button.component.html',
  styleUrls: ['./button.component.css']
})
export class ButtonComponent implements OnInit {

  @Input() label: string|any;
  @Output() onClick = new EventEmitter<any>();
  @Output() onClick2 = new EventEmitter<any>();



  constructor() { }

  ngOnInit(): void {
  }

  buttonClick(event:any) {
      this.onClick.emit('Clicked button 1');
      this.onClick2.emit('Clicked button 2');
  }
}
